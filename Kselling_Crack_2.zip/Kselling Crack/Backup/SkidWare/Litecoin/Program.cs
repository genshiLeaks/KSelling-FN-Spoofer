﻿using System;
using System.Diagnostics;
using System.Net;
using System.Threading;
using System.Windows.Forms;
using KeyAuth;

namespace Litecoin
{
	// Token: 0x02000002 RID: 2
	internal class Program
	{
		// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
		private static void Main()
		{
			Console.Title = "Loader";
			Console.WriteLine("\n\n Connecting..");
			Program.KeyAuthApp.init();
			Program.autoUpdate();
			bool flag = !Program.KeyAuthApp.response.success;
			if (flag)
			{
				Console.WriteLine("\n Status: " + Program.KeyAuthApp.response.message);
				Thread.Sleep(1500);
				Environment.Exit(0);
			}
			Program.KeyAuthApp.check();
			Console.WriteLine(" KSelling Spoofer Connection: " + Program.KeyAuthApp.response.message);
			Console.Write("\n  [4] License key only\n  Choose option: ");
			switch (int.Parse(Console.ReadLine()))
			{
			case 1:
			{
				Console.Write("\n\n Enter username: ");
				string username = Console.ReadLine();
				Console.Write("\n\n Enter password: ");
				string pass = Console.ReadLine();
				Program.KeyAuthApp.login(username, pass);
				break;
			}
			case 2:
			{
				Console.Write("\n\n Enter username: ");
				string username = Console.ReadLine();
				Console.Write("\n\n Enter password: ");
				string pass = Console.ReadLine();
				Console.Write("\n\n Enter license: ");
				string key = Console.ReadLine();
				Console.Write("\n\n Enter email (just press enter if none): ");
				string email = Console.ReadLine();
				Program.KeyAuthApp.register(username, pass, key, email);
				break;
			}
			case 3:
			{
				Console.Write("\n\n Enter username: ");
				string username = Console.ReadLine();
				Console.Write("\n\n Enter license: ");
				string key = Console.ReadLine();
				Program.KeyAuthApp.upgrade(username, key);
				Console.WriteLine("\n Status: " + Program.KeyAuthApp.response.message);
				Thread.Sleep(2500);
				Environment.Exit(0);
				break;
			}
			case 4:
			{
				Console.Write("\n\n Enter license: ");
				string key = Console.ReadLine();
				Program.KeyAuthApp.license(key);
				break;
			}
			case 5:
			{
				Console.Write("\n\n Enter username: ");
				string username = Console.ReadLine();
				Console.Write("\n\n Enter email: ");
				string email = Console.ReadLine();
				Program.KeyAuthApp.forgot(username, email);
				Console.WriteLine("\n Status: " + Program.KeyAuthApp.response.message);
				Thread.Sleep(2500);
				Environment.Exit(0);
				break;
			}
			default:
				Console.WriteLine("\n\n Invalid Selection");
				Thread.Sleep(2500);
				Environment.Exit(0);
				break;
			}
			bool flag2 = !Program.KeyAuthApp.response.success;
			if (flag2)
			{
				Console.WriteLine("\n Status: " + Program.KeyAuthApp.response.message);
				Thread.Sleep(2500);
				Environment.Exit(0);
			}
			Console.WriteLine("\n Logged In!");
			Console.WriteLine("\n User data:");
			Console.WriteLine(" Username: " + Program.KeyAuthApp.user_data.username);
			Console.WriteLine(" IP address: " + Program.KeyAuthApp.user_data.ip);
			Console.WriteLine(" Hardware-Id: " + Program.KeyAuthApp.user_data.hwid);
			Console.WriteLine(" Created at: " + Program.UnixTimeToDateTime(long.Parse(Program.KeyAuthApp.user_data.createdate)).ToString());
			bool flag3 = !string.IsNullOrEmpty(Program.KeyAuthApp.user_data.lastlogin);
			if (flag3)
			{
				Console.WriteLine(" Last login at: " + Program.UnixTimeToDateTime(long.Parse(Program.KeyAuthApp.user_data.lastlogin)).ToString());
			}
			Console.WriteLine(" Your subscription(s):");
			for (int i = 0; i < Program.KeyAuthApp.user_data.subscriptions.Count; i++)
			{
				Console.WriteLine(string.Concat(new string[]
				{
					" Subscription name: ",
					Program.KeyAuthApp.user_data.subscriptions[i].subscription,
					" - Expires at: ",
					Program.UnixTimeToDateTime(long.Parse(Program.KeyAuthApp.user_data.subscriptions[i].expiry)).ToString(),
					" - Time left in seconds: ",
					Program.KeyAuthApp.user_data.subscriptions[i].timeleft
				}));
			}
			for (;;)
			{
				Console.Clear();
				Console.ForegroundColor = ConsoleColor.DarkMagenta;
				Console.Title = " KSelling - Paid ";
				Console.ForegroundColor = ConsoleColor.Magenta;
				Console.WriteLine();
				Console.WriteLine();
				Console.WriteLine("                        [ <1> ] Spoof");
				Console.WriteLine();
				Console.WriteLine();
				Console.WriteLine("                        [ <2> ] Clean");
				Console.WriteLine();
				Console.WriteLine();
				Console.WriteLine("                        [ <3> ] Check Serials");
				Console.WriteLine();
				Console.WriteLine();
				Console.Write(" </> ");
				string a = Console.ReadLine();
				bool flag4 = a == "1";
				if (flag4)
				{
					Spoofer.Spoof();
					Console.Clear();
				}
				else
				{
					bool flag5 = a == "2";
					if (flag5)
					{
						Spoofer.Clean();
						Thread.Sleep(1000);
						Console.Clear();
					}
					else
					{
						bool flag6 = a == "3";
						if (flag6)
						{
							Spoofer.Serials();
							Thread.Sleep(1000);
							Console.Clear();
						}
						else
						{
							Console.Clear();
							Console.WriteLine("Please Choose a Valid Option!");
							Thread.Sleep(2000);
							Console.Clear();
						}
					}
				}
			}
		}

		// Token: 0x06000002 RID: 2 RVA: 0x00002610 File Offset: 0x00000810
		public static DateTime UnixTimeToDateTime(long unixtime)
		{
			DateTime result = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Local);
			try
			{
				result = result.AddSeconds((double)unixtime).ToLocalTime();
			}
			catch
			{
				result = DateTime.MaxValue;
			}
			return result;
		}

		// Token: 0x06000003 RID: 3 RVA: 0x00002668 File Offset: 0x00000868
		private static void autoUpdate()
		{
			bool flag = Program.KeyAuthApp.response.message == "invalidver";
			if (flag)
			{
				bool flag2 = !string.IsNullOrEmpty(Program.KeyAuthApp.app_data.downloadLink);
				if (flag2)
				{
					Console.WriteLine("\n Auto update avaliable!");
					Console.WriteLine(" Choose how you'd like to auto update:");
					Console.WriteLine(" [1] Open file in browser");
					Console.WriteLine(" [2] Download file directly");
					int num = int.Parse(Console.ReadLine());
					int num2 = num;
					int num3 = num2;
					if (num3 != 1)
					{
						if (num3 != 2)
						{
							Console.WriteLine(" Invalid selection, terminating program..");
							Thread.Sleep(1500);
							Environment.Exit(0);
						}
						else
						{
							Console.WriteLine(" Downloading file directly..");
							Console.WriteLine(" New file will be opened shortly..");
							WebClient webClient = new WebClient();
							string text = Application.ExecutablePath;
							string str = Program.random_string();
							text = text.Replace(".exe", "-" + str + ".exe");
							webClient.DownloadFile(Program.KeyAuthApp.app_data.downloadLink, text);
							Process.Start(text);
							Process.Start(new ProcessStartInfo
							{
								Arguments = "/C choice /C Y /N /D Y /T 3 & Del \"" + Application.ExecutablePath + "\"",
								WindowStyle = ProcessWindowStyle.Hidden,
								CreateNoWindow = true,
								FileName = "cmd.exe"
							});
							Environment.Exit(0);
						}
					}
					else
					{
						Process.Start(Program.KeyAuthApp.app_data.downloadLink);
						Environment.Exit(0);
					}
				}
				Console.WriteLine("\n Status: Version of this program does not match the one online. Furthermore, the download link online isn't set. You will need to manually obtain the download link from the developer.");
				Thread.Sleep(2500);
				Environment.Exit(0);
			}
		}

		// Token: 0x06000004 RID: 4 RVA: 0x00002818 File Offset: 0x00000A18
		private static string random_string()
		{
			string text = null;
			Random random = new Random();
			for (int i = 0; i < 5; i++)
			{
				text += Convert.ToChar(Convert.ToInt32(Math.Floor(26.0 * random.NextDouble() + 65.0))).ToString();
			}
			return text;
		}

		// Token: 0x04000001 RID: 1
		public static api KeyAuthApp = new api("KSellingSpoofer", "Fe5zQqCIID", "a92eaf602519514a60199a9e3e89bfb52ea1a280fc7f5d3123b3ed51cabbe133", "1.0");
	}
}
